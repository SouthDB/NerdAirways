---drop all SEQUENCE from NerdAirways---

DROP SEQUENCE aw_arti_seq;
DROP SEQUENCE aw_cred_seq;
DROP SEQUENCE aw_coun_seq;
DROP SEQUENCE aw_cust_seq;
DROP SEQUENCE aw_term_seq;
DROP SEQUENCE aw_fligstat_seq;
DROP SEQUENCE aw_flig_seq;
DROP SEQUENCE aw_clas_seq;
DROP SEQUENCE aw_lugg_seq;
DROP SEQUENCE aw_book_seq;
DROP SEQUENCE aw_revi_seq;

DROP SEQUENCE aw_flightNR_seq;
DROP SEQUENCE aw_bookingNR_seq;