---request for last gernerated Sequence Number from NerdAirways---

SELECT aw_arti_seq.currval FROM dual;
SELECT aw_cred_seq.currval FROM dual;
SELECT aw_coun_seq.currval FROM dual;
SELECT aw_cust_seq.currval FROM dual;
SELECT aw_term_seq.currval FROM dual;
SELECT aw_fligstat_seq.currval FROM dual;
SELECT aw_flig_seq.currval FROM dual;
SELECT aw_clas_seq.currval FROM dual;
SELECT aw_lugg_seq.currval FROM dual;
SELECT aw_book_seq.currval FROM dual;
SELECT aw_revi_seq.currval FROM dual;

SELECT aw_flightNR_seq.currval FROM dual;
SELECT aw_bookingNR_seq.currval FROM dual;