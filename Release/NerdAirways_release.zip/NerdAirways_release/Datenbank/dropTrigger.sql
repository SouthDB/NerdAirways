---drop all TRIGGER from NerdAirways---

DROP TRIGGER aw_arti_bir;
DROP TRIGGER aw_cred_bir;
DROP TRIGGER aw_coun_bir;
DROP TRIGGER aw_cust_bir;
DROP TRIGGER aw_term_bir;
DROP TRIGGER aw_fligstat_bir;
DROP TRIGGER aw_flig_bir;
DROP TRIGGER aw_clas_bir;
DROP TRIGGER aw_lugg_bir;
DROP TRIGGER aw_book_bir;
DROP TRIGGER aw_revi_bir;